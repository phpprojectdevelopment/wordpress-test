<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress_test' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ' qugG>>nWJ_<:B>E/v C;*eo@,t`b7/;hf.Bq36dZi5VaYKOfS-;>wyDK**{Myvb' );
define( 'SECURE_AUTH_KEY',  'NDix`Csl5>t>c4<E>UxIZm0|Y>S^TnYI/9`.>ff;ptl+v45~Q!J::jdkP@DSiZ,_' );
define( 'LOGGED_IN_KEY',    'v$u^ib=%>(gx+O)xS5=AbG]eXa!W;v0TxXgR}#r2PAL&3SV$wE87dNLT]Fh@QrR[' );
define( 'NONCE_KEY',        'YbBC,weZ}Ae5()Ao)X[:7/EL-85<[O*?1t3B5dX|Qau>@I0EqA!aPaKoHs+KcHpL' );
define( 'AUTH_SALT',        'hxpMyWx5b{{!Bdrc3_;_*2]cDk??)CR~lz5Ar=B_=^>t3L!E$L;R;_u: E=i_U1 ' );
define( 'SECURE_AUTH_SALT', 'rh$^?WB4Ez1P0ha>84ZHS^V`#}>>g5Lq~wdzW$U0noufUs7H~x|MLbLb@SGxT|E0' );
define( 'LOGGED_IN_SALT',   '[Ep!pn=7MI.M|)Vdjf XtPu5X~K(h&UN3hxYb@/6< v<|:O8ceAR2q$NZ#sS&Sby' );
define( 'NONCE_SALT',       '_K 8vYL+|eLR q~AiFDf|@GY`sQey$DT%:6t|/EMgrP7v<S<zVyw%an}*?*=YMC/' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
